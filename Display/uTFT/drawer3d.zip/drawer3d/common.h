#include <stdint.h>


//#define bool uint8_t
//#define true 1
//#define false 0

#define FPS_MIN 30
#define FPS_MAX 60