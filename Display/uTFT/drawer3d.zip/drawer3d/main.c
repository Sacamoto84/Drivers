/* Very simple 3d engine for drawing simple,
* low poly 3d .obj mesh models.
* and yes, i know what here lots of optimizations can be!
* but i`m so lazy to do that...
* 
*
*
* Author: Alexandr Antonov (Bismuth208)
* Created:  13.08.2015
*/


#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <stm32f10x.h>

#include <gfx.h>
#include <gfxDMA.h>
#include <spi.h>
#include <systicktimer.h>

#include "common.h"
#include "engine.h"
#include "trigonometry.h"



//-----------------------------------------------------------//
//Yes, we have no itoa() in IAR, and yes it`s from wiki ))
void reverse(char s[])
{
  int i, j;
  char c;
  for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
    c = s[i];
    s[i] = s[j];
    s[j] = c;
  }
}

void itoa(int n, char s[])
{
  int i, sign;
  if ((sign = n) < 0) //remeber sign 
    n = -n; // make n to positive
  i = 0;
  do { //generate numbers in reverse 
    s[i++] = n % 10 + '0'; //get next number
  } while ((n /= 10) > 0); // remove 
  
  if (sign < 0)
    s[i++] = '-';
  s[i] = '\0';
  reverse(s);
}
//-----------------------------------------------------------//
void startupInit()
{
  //NOTE! STM32 confugired for 72Mhz Sys clock!
  //to change that go to "system_stm32f10x.c"
  //and find "#define SYSCLK_FREQ_72MHz  72000000"
  //select what you need
  SystemInit(); //init clocks and another s...
  initSysTickTimer();

  init_SPI1();

  //tftBegin();         // initialize a ILI9341 chip
  initR(INITR_BLACKTAB);
  tftSetRotation(1);
  tftFillScreen(COLOR_RED); // COLOR_RED
  
  setTextColorBG(COLOR_GREEN, COLOR_BLACK);
  //setTextColor(COLOR_GREEN);
}


void main()
{
  startupInit();
  
  uint32_t lastMicros, thisMicros, resultMicros;
  uint32_t delayLong = 30;
  uint32_t fps = 0;
  static char bufMsec[4], bufFps[4], bufDelay[4];

  
  uint16_t distPeriod1 = 0;
  
#if NEW_ENGINE  
  uint8_t xAngle1 = 123;
  uint8_t yAngle1 = 32;
#endif
  
#if OLD_ENGINE
    scaleModel();
#endif
  
  for(;;) {
    //This show how long we draw previous frame
    lastMicros = thisMicros;
    thisMicros = _uptime();
    resultMicros = thisMicros - lastMicros;
    
    fps = 1000/resultMicros;
 
    if(fps <= FPS_MIN) --delayLong;    //trying to get 30 fps
    if(fps >= FPS_MAX) ++delayLong;    //but not more 60 fps
    
    itoa(resultMicros, bufMsec);
    itoa(fps, bufFps);
    itoa(delayLong, bufDelay);
    

    //first: fill buffer
#if NEW_ENGINE
    rotate_all_points(xAngle1, yAngle1, ((tsin(distPeriod1 >> 8) + 280) * 100) >> 8);
    find_visible_points();
    draw_all_lines();
    
    xAngle1 += 3;
    yAngle1 += 1;
    distPeriod1 += 439;
#endif
    
#if OLD_ENGINE
    calcWireframe(distPeriod1);
    draw_wireframe();
    ++distPeriod1;
#endif
    
    //u8g_DrawStr(&u8g, 0, 15, bufMsec);     //Show in ms drawing time of single frame
    //u8g_DrawStr(&u8g, 0, 25, bufFps);      //Show fps
    //u8g_DrawStr(&u8g, 0, 35, bufDelay);    //Show delayLong
    
    _delayMS(delayLong); //slow down! it`s too faast!
    
    tftFillScreen(COLOR_BLACK);
  }
}


#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
 
  /* Infinite loop */
  while (1)
  {
  }
}
#endif