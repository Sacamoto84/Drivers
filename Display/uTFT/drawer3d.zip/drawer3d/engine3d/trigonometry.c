#include <stdint.h>

#include "trigonometry.h"
#include "sintables.h"

float romsin(float x)
{
  int16_t ix ;   // index into sin table
  int16_t is ;   // value read from sin table

  x *= 1./360. ;
  x -= (int16_t)x ;
  
  if (x < 0)
    x += 1.0 ;   // x is now between 0 and 1, representing 0 to 360 degrees
  
  ix = (int16_t)(x*4*NS) % NS ;  // get index into table
  
  switch( (int16_t)(x*4) ) // get quadrant number 0,1,2,3
  {
  case 0:   // 0-90
    is = sintab[ix];
    break ;
  case 1:   // 90-180
    ix = NS - ix - 1 ;  // reflect
    is = sintab[ix];
    break ;
  case 2:   // 180-270
    is = -sintab[ix];  // negate
    break ;
  case 3:   // 270-360
    ix = NS - ix - 1;   // reflect
    is = -sintab[ix];   // negate
    break ;
  }
  
  return((float)is*I2F);
}

float romcos(float x)
{
  return romsin(x+90);
}

int16_t tsin(uint8_t period)
{
  if (period >= 0x80)
    return (period > 0xC0) ? -(sintable[0x100 - period]) : -(sintable[period - 0x80]);
  else
    return (period > 0x40) ? (sintable[0x80 - period]) : (sintable[period]);
}

int16_t tcos(uint8_t period)
{
  if (period >= 0x80)
    return (period > 0xC0) ? (sintable[period - 0xC0]) : -(sintable[0xC0 - period]);
  else
    return (period > 0x40) ? -(sintable[period - 0x40]) : (sintable[0x40 - period]);
}
