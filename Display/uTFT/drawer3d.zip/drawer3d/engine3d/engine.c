#include <stdint.h>

#include <gfx.h>

#include "trigonometry.h"
#include "engine.h"

//include here your model
#include "model.h"
#include "tie_fighter_lp_nf.h"  //this one only for OLD_ENGINE

//=================================================//
#if NEW_ENGINE
void rotate_all_points(uint8_t xAngle, uint8_t yAngle, uint8_t distAdd)
{
  int16_t ax, ay, az;
  int16_t s, c;
  int16_t t;
  
  for (uint8_t i = 0; i < arraysize(points); i++) {
    ax = points[i].x;
    ay = points[i].y;
    az = points[i].z;
    
    s = tsin(xAngle);
    c = tcos(xAngle);
    t = (ay * c - az * s) / CONST_DEVIDER;
    az = (az * c + ay * s) / CONST_DEVIDER;
    ay = t;
    
    s = tsin(yAngle);
    c = tcos(yAngle);
    t = (ax * c - az * s) / CONST_DEVIDER;
    az = (az * c + ax * s) / CONST_DEVIDER;
    ax = t;
    
    az = az + 200 + distAdd;
    vpoints[i].x = ax * 64 / az + ZERO_POINTX; // ����������� ������������, ������� ��������� ������ ��� X � Y
    vpoints[i].y = ay * 54 / az + ZERO_POINTY;
    vpoints[i].isVisible = 0;
  }
}

void find_visible_points()
{
  uint16_t p1, p2, p3;
  int16_t dx1, dy1, dx2, dy2;
  int16_t v;
  uint8_t pcnt;
  
  for (uint8_t i = 0; i < arraysize(surfaces); i++) {
    p1 = surfaces[i].points[0];
    p2 = surfaces[i].points[1];
    p3 = surfaces[i].points[2];
    
    dx1 = vpoints[p1].x - vpoints[p2].x;
    dy1 = vpoints[p1].y - vpoints[p2].y;
    dx2 = vpoints[p3].x - vpoints[p2].x;
    dy2 = vpoints[p3].y - vpoints[p2].y;

    v = (dx1 * dy2) - (dy1 * dx2);
    if (v > 0) {
      vpoints[p1].isVisible = 1;
      vpoints[p2].isVisible = 1;
      vpoints[p3].isVisible = 1;
      pcnt = surfaces[i].cnt;
      
      if (pcnt >= 4) 
        vpoints[surfaces[i].points[3]].isVisible = 1;
      if (pcnt >= 5)
        vpoints[surfaces[i].points[4]].isVisible = 1;
      
    }
  }
}

void draw_all_lines()
{
  uint16_t p1, p2;
  
  for (uint8_t i = 0; i < arraysize(lines); i++) {
    p1 = lines[i].p1;
    p2 = lines[i].p2;
    
    if (vpoints[p1].isVisible && vpoints[p2].isVisible)
      tftDrawLine(vpoints[p1].x, vpoints[p1].y, vpoints[p2].x, vpoints[p2].y, COLOR_WHITE);
  } 
}
#endif

//------------------------------------------------------------//
#if OLD_ENGINE //this is old one, and draw only wireframe modeles from objparser
float rotx, roty, rotz,  rotyy, rotzz, rotxxx, rotyyy;
uint8_t count, edgeCount;


void draw_wireframe(void)
{
 for (edgeCount = 0; edgeCount < EDGES_COUNT; edgeCount++) {
   //model_edges[][] -1 :: fix edges for wireframe
   //i am too lazy to make it in objparser
     tftDrawLine(wireframe[model_edges[edgeCount][0] -1][0],
                 wireframe[model_edges[edgeCount][0] -1][1],
                 wireframe[model_edges[edgeCount][1] -1][0],
                 wireframe[model_edges[edgeCount][1] -1][1],
                 COLOR_WHITE);
 }
}

void calcWireframe(uint16_t angle)
{
  float sinRot = romsin(angle);
  float cosRot = romcos(angle);
  
  for (count = 0; count < VERTEX_COUNT; count++) {
//rotateY
    rotx = model_vertex[count][2] * cosRot + model_vertex[count][0] * sinRot;
    roty = model_vertex[count][2] * sinRot - model_vertex[count][0] * cosRot;
    rotz = model_vertex[count][1];
       
//rotateX
    rotyy = roty * cosRot + rotz * sinRot;
       
//rotateZ
    rotyyy = rotx * cosRot - rotyy * sinRot;
    rotxxx = rotx * sinRot + rotyy * cosRot;

//store new vertices values for wireframe + zero point of x, y
    wireframe[count][0] = rotxxx + ZERO_POINTX;
    wireframe[count][1] = rotyyy + ZERO_POINTY;
  }
}

void scaleModel(void) //if model small on screen, make it bigger
{
  for (count = 0; count < VERTEX_COUNT; count++) {
    model_vertex[count][0] *= SCALE_SIZE;
    model_vertex[count][1] *= SCALE_SIZE;
    model_vertex[count][2] *= SCALE_SIZE;
  }
}
/*
void initModel(void) //fix edges for wireframe
{
  for (count = 0; count < EDGES_COUNT; count++) {
    model_edges[count][0] -= 1;
    model_edges[count][1] -= 1;
  }
}
*/
#endif
//------------------------------------------------------------//