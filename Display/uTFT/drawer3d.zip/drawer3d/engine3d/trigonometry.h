#ifndef _TRIGONOMETRY_H
#define _TRIGONOMETRY_H

//http://forum.arduino.cc/index.php?topic=69723.0
//http://forum.arduino.cc//index.php?topic=196625.msg1453433#msg1453433

//this one used; thx u "jmknapp"
//http://forum.arduino.cc/index.php?topic=75126.0


#define NS 1024   // number of entries in sin table
#define MAXI 32768  // max integer value in table
#define I2F (1./MAXI) // conversion from integer to float

int16_t tsin(uint8_t period);
int16_t tcos(uint8_t period);
float romsin(float);
float romcos(float);

#endif